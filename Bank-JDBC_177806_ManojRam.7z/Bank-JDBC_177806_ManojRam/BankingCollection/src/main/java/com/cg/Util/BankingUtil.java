package com.cg.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;

public class BankingUtil {
	static Map<Integer, Account> accountDatabase = new HashMap<Integer, Account>();
	static Map<Integer, Wallet> walletDatabase = new HashMap<Integer, Wallet>();
	static List<String> transactList = new ArrayList<String>();
	static List<String> walletTransactList = new ArrayList<String>();
	static Map<Integer, Transactions> transactionsDatabase = new HashMap<Integer, Transactions>();
	static Map<Integer, WalletTransactions> walletTransactionsDatabase = new HashMap<Integer, WalletTransactions>();

	// Transactions transact = new Transactions();

	public BankingUtil() {
		accountDatabase.put(1, new Account(1, "Manoj", "9080706050", 50000d));
		accountDatabase.put(2, new Account(2, "Ram", "9180706050", 25000d));
		accountDatabase.put(3, new Account(3, "Abi", "9280706050", 10000d));
		accountDatabase.put(4, new Account(4, "Jerr", "9380706050", 12500d));
		accountDatabase.put(5, new Account(5, "Vijay", "9480706050", 37500d));

		walletDatabase.put(1, new Wallet(1, 0));
		walletDatabase.put(2, new Wallet(2, 0));
		walletDatabase.put(3, new Wallet(3, 0));
		walletDatabase.put(4, new Wallet(4, 0));
		walletDatabase.put(5, new Wallet(5, 0));

		Transactions transact1 = new Transactions();
		transact1.addToTransactionList(50000 + "cr -> \t" + 50000);
		storeIntoTransactionsDatabase(1, transact1);

		Transactions transact2 = new Transactions();
		transact2.addToTransactionList(25000 + "cr -> \t" + 25000);
		storeIntoTransactionsDatabase(2, transact2);

		Transactions transact3 = new Transactions();
		transact3.addToTransactionList(10000 + "cr -> \t" + 10000);
		storeIntoTransactionsDatabase(3, transact3);

		Transactions transact4 = new Transactions();
		transact4.addToTransactionList(12500 + "cr -> \t" + 12500);
		storeIntoTransactionsDatabase(4, transact4);

		Transactions transact5 = new Transactions();
		transact5.addToTransactionList(37500 + "cr -> \t" + 37500);
		storeIntoTransactionsDatabase(5, transact5);
	}

	public static void addToTransactionList(String transaction) {
		transactList.add(transaction);
	}

	public static void addToWalletTransactionList(String transaction) {
		walletTransactList.add(transaction);
	}

	public static void storeIntoAccountDatabase(Account account) {
		accountDatabase.put(account.getAccountNumber(), account);
	}

	public static Account getFromAccountDatabase(int accountNumber) {
		return accountDatabase.get(accountNumber);
	}

	public static void storeIntoWalletDatabase(Wallet wallet) {
		walletDatabase.put(wallet.getWalletID(), wallet);
	}

	public static Wallet getFromWalletDatabase(int walletID) {
		return walletDatabase.get(walletID);
	}

	public static void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions) {
		transactionsDatabase.put(accountNumber, transactions);
	}

	public static Transactions getFromTransactionsDatabase(int accountNumber) {
		return transactionsDatabase.get(accountNumber);
	}

	public static void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions) {
		walletTransactionsDatabase.put(walletID, walletTransactions);
	}

	public static WalletTransactions getFromWalletTransactionsDatabase(int walletID) {
		return walletTransactionsDatabase.get(walletID);
	}

	public static Map<Integer, Account> getAccountDatabase() {
		return accountDatabase;
	}

	public static void setAccountDatabase(Map<Integer, Account> accountDatabase) {
		BankingUtil.accountDatabase = accountDatabase;
	}

	public static int getAccountCount() {
		return accountDatabase.size();
	}

	// Print all data from map
	public static void getTransactionFromWalletDatabase() {
		for (Integer aKey : walletTransactionsDatabase.keySet()) {
			WalletTransactions aValue = walletTransactionsDatabase.get(aKey);
			System.out.println(aKey + " " + aValue);
		}
	}

	// Print all data from map
	public static void getTransactionFromAccountDatabase() {
		for (Integer aKey : transactionsDatabase.keySet()) {
			Transactions aValue = transactionsDatabase.get(aKey);
			System.out.println(aKey + " " + aValue);
		}
	}
}
