package com.cg.Exception;

public class BankException extends Exception {
	private static final long serialVersionUID = 1L;

	public BankException(String exception) {
		super(exception);
	}
}
