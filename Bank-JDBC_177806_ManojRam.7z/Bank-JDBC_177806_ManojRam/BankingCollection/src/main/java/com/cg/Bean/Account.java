package com.cg.Bean;

public class Account {
	private int accountNumber;
	private String name;
	private String mobileNumber;
	private double amount;
	private Wallet wallet = new Wallet();

	public Account() {
		this.accountNumber = 0;
		this.name = null;
		this.mobileNumber = null;
		this.amount = 0;
	}

	public Account(int accountNumber, String name, String mobileNumber, double amount) {
		this.accountNumber = accountNumber;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.amount = amount;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "" + "\nAccount Number: " + accountNumber + "\nHolder's Name: " + name + "\nMobile Number: "
				+ mobileNumber + "\nAccount Balance: " + amount + "\nWallet ID: " + getWallet().getWalletID()
				+ "\nWallet Balance: " + getWallet().getWalletAmount();
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
}
