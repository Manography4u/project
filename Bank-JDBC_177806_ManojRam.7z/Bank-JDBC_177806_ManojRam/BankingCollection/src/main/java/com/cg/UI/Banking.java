package com.cg.UI;

import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;
import com.cg.Service.BankService;
import com.cg.Service.BankServiceImpl;
import com.cg.Util.BankingUtil;

public class Banking {
	static public int accountNumber;
	static boolean bool;
	static public int walletID;
	static double transferableAmount = 0;
static Scanner input = new Scanner(System.in);
	static Account account = new Account();
	
	static BankService CGbankserv = new BankServiceImpl();
	static BankingUtil util = new BankingUtil();
	static Transactions transact = new Transactions();
	static WalletTransactions walletTransact = new WalletTransactions();

	// Main menu
	public static void mainMenu() throws Exception {
		bool = true;

		while (bool) {
			System.out.println("\n \n\t0. Terminate App \n\t 1. Check Balance \n\t 2. Deposit Amount \n\t 3. Withdraw Amount \n \t 4. Fund Transfer \n\t 5. Transaction History \n\t 6. Account Details \n\t 7. Logout");
		
			System.out.print("\n Enter Your Choice: ");
			switch (input.nextInt()) {
			case 0:
				bool = false;
				break;
			case 1:
				showBalance();
				break;
			case 2:
				depositAmount();
				break;
			case 3:
				withdrawAmount();
				break;
			case 4:
				fundTransfer();
				break;
			case 5:
				printTransaction();
				break;
			case 6:
				accountDetails();
				break;
			case 7:
				main(null);
				/* transact = null; walletTransact = null; */break;
			default:
				System.out.println("\n Invalid option");
				break;
			}
		}
	}

	// Create Account
	public static void createAccount() throws Exception {
		Account newAccount = new Account();
		Wallet newWallet = new Wallet();

		newAccount.setAccountNumber(++accountNumber + 5);

		System.out.print("Enter Your Name:");
		newAccount.setName(input.next());
		System.out.println();

		System.out.print("Enter Your Mobile Number:");
		newAccount.setMobileNumber(input.next());
		System.out.println();

		System.out.print("Enter Initial Deposit Amount:");
		newAccount.setAmount(input.nextInt());
		creditAccount(newAccount.getAmount());
		System.out.println();

		// Store Account Data into BankService
		CGbankserv.storeIntoAccountDatabase(newAccount);
	

		// Wallet Data
		newWallet.setWalletID(++walletID + 5);
		newWallet.setWalletAmount(0);

		// Store Wallet Data into BankService
		CGbankserv.storeIntoWalletDatabase(newWallet);

		// Initial Transaction
		transact.addToTransactionList(newAccount.getAmount() + "cr -> \t" + newAccount.getAmount());
		CGbankserv.storeIntoTransactionsDatabase(newAccount.getAccountNumber(), transact);

		// Display Account Info
		System.out.println("\t \t \tAccount Succesfully Created ");
		System.out.println("\n\tYour Account Number(UserName): " + "RB000" + newAccount.getAccountNumber());
		System.out.println("\tYour Mobile Number(Password): " + newAccount.getMobileNumber());
		System.out.println("\tYour Wallet Id " + "WM000" + newWallet.getWalletID());
	}

	// Shows Balance in Account & Wallet
	public static void showBalance() throws Exception {
		bool = true;

		while (bool) {
			System.out.println("\nEnter your choice:");
			System.out.println("\n0.Back");
			System.out.println("\n\t1.Account");
			System.out.println("\n\t2.Wallet");

			System.out.print("\nYour Choice: ");
			switch (input.nextInt()) {
			case 0:
				bool = false;
				mainMenu();
				break;
			case 1:
				System.out.println("\nYour Account Balance: " + account.getAmount());
				break;
			case 2:
				System.out.println("\nYour Wallet Balance: " + account.getWallet().getWalletAmount());
				break;
			default:
				System.out.println("\tInvalid option");
				showBalance();
				break;
			}
		}
	}

	// Credit in Account
	public static void depositAmount() throws Exception {
		System.out.print("\n\tEnter the amount yout want to deposit: ");
		transferableAmount = input.nextInt();
		creditAccount(transferableAmount);
		getAccountBalance.accept("");

	}

	// Debit from Account
	public static void withdrawAmount() throws Exception {
		System.out.print("\n\tEnter the amount yout want to withdraw: ");
		transferableAmount = input.nextInt();
		debitAccount(transferableAmount);
		getAccountBalance.accept("");
	}

	// Tranfer funds
	public static void fundTransfer() throws Exception {
		bool = true;

		while (bool) {

			System.out.println("\n\t \t \t Enter your choice");
			System.out.println("\n0.Back");
			System.out.println("\t1. Bank to Wallet");
			System.out.println("\t2. Wallet to Bank");
			System.out.println("\t3. Bank to Bank");
			System.out.println("\t4. Wallet to Wallet");
			System.out.println("\t5. Bank to Another Wallet");

			try {
				System.out.print("\t\t\t\nYour Choice: ");
				switch (input.nextInt()) {
				case 0: {
					bool = false;
					mainMenu();
					break;
				}

				// Transfer from Bank to Wallet
				case 1: {
					System.out.print("\nEnter the amount to be transfered to wallet: ");
					transferableAmount = input.nextInt();

					debitAccount(transferableAmount);
					creditWallet(transferableAmount);

					getAccountBalance.accept("");
					getWalletBalance.accept("");
				}
					break;

				// Transfer from Wallet to Bank
				case 2: {
					System.out.print("\nEnter the amount to be transfered to Bank: ");
					transferableAmount = input.nextInt();

					debitWallet(transferableAmount);
					creditAccount(transferableAmount);

					getAccountBalance.accept("");
					getWalletBalance.accept("");
				}
					break;

				// Transfer from Bank to Another bank
				case 3: {

					System.out.print("\nEnter account number to which you want to transfer the amount: RB000");
					int accountNumber = input.nextInt();

					if (CGbankserv.getAccountCount() >= accountNumber) {
						Account anotherAccount = CGbankserv.getFromAccountDatabase(accountNumber);

						System.out.print("\nEnter the amount to be transfered to Another Account: ");
						transferableAmount = input.nextInt();

						debitAccount(transferableAmount);
						creditAccount(transferableAmount, anotherAccount);

						getAccountBalance.accept("");
					}
				}
					break;

				// Transfer from Wallet to Another Wallet
				case 4: {
					System.out.print("\nEnter wallet ID to which you want to transfer the amount: WM000");
					int walletID = input.nextInt();

					if (validateAccountNumber(walletID)) {
						Wallet anotherWallet = CGbankserv.getFromWalletDatabase(walletID);

						System.out.print("\nEnter the amount to be transfered to Another Wallet: ");
						transferableAmount = input.nextInt();

						debitWallet(transferableAmount);
						creditWallet(transferableAmount, anotherWallet);

						getWalletBalance.accept("");
					}
				}
					break;

				// Transfer from Bank to Another Wallet
				case 5: {
					System.out.print("\nEnter wallet ID to which you want to transfer the amount: WM000");
					int walletID = input.nextInt();

					if (validateAccountNumber(walletID)) {
						Wallet anotherWallet = CGbankserv.getFromWalletDatabase(walletID);

						System.out.print("\nEnter the amount to be transfered to Another Wallet: ");
						transferableAmount = input.nextInt();

						debitAccount(transferableAmount);
						creditWallet(transferableAmount, anotherWallet);

						getAccountBalance.accept("");
					}
				}
					break;

				default: {
					System.out.println("\nInvalid option");
					fundTransfer();
					break;
				}
				}

			}

			catch (Exception e) {
				System.out.println("\nInvalid Operation");
				System.out.println(e);
				bool = false;
			}

			finally {
				if (!bool)
					mainMenu();
			}
		}
	}

	// Get Transaction History
	public static void printTransaction() throws Exception {
		Transactions transaction = CGbankserv.getFromTransactionsDatabase(account.getAccountNumber());
		WalletTransactions walletTransaction = CGbankserv
				.getFromWalletTransactionsDatabase(account.getWallet().getWalletID());

		bool = true;

		while (bool) {
			System.out.println("\nEnter your choice: ");
			System.out.println("\n0.Back");
			System.out.println("1.Account");
			System.out.println("2.Wallet");

			System.out.print("Your Choice: ");
			switch (input.nextInt()) {
			case 0: {
				bool = false;
				mainMenu();
				break;
			}

			case 1: {
				if (transaction != null) {
					System.out.println("\nTransaction History:");
					System.out.println("Cr./Dr. \tBalance");
					for (String transactions : transaction.getTransactList())
						System.out.println(transactions);
				}

				else
					System.out.println("\nNo Transactions Yet!");
				//BankService.getTransactionFromAccountDatabase();
			}
				break;

			case 2: {
				if (walletTransaction != null) {
					System.out.println("\nTransaction History:");
					System.out.println("Cr./Dr. \tBalance");
					for (String walletTransactions : walletTransaction.getTransactList())
						System.out.println(walletTransactions);
					// rBankService.getDataFromMap();
				}

				else
					System.out.println("\nNo Transactions Yet!");
				//BankService.getTransactionFromWalletDatabase();

			}
				break;

			default:
				System.out.println("Invalid option");
			}
		}

	}

	public static void accountDetails() {
		System.out.println(account);
	}

	

	// User Interface
	public static void main(String[] args) throws Exception {
		bool = true;

		while (bool) {
			System.out.println("\n\n########  Welcome To CG Bank  ##############\n");
			System.out.println("\nEnter Your Choice: ");
			System.out.println("\n\t\t0. Terminate App");
			System.out.println("\t\t1. Login");
			System.out.println("\t\t2. Create Account.");

			System.out.print("\nYour Choice: ");
			switch (input.nextInt()) {
			case 0: {
				bool = false;
				break;
			}
			case 1: {
				validateAccount();
				bool = false;
				break;
			}
			case 2: {
				createAccount();
				break;
			}
			default: {
				System.out.println("\nInvalid option");
				break;
			}
			}
		}
	}



	static Consumer<String> getAccountBalance = balance -> System.out
			.println("\nUpdated Account Balance: " + account.getAmount());
	static Consumer<String> getWalletBalance = balance -> System.out
			.println("\nUpdated Wallet Balance: " + account.getWallet().getWalletAmount());

	// Validate User Credentials
	public static void validateAccount() throws Exception {
		bool = true;

		while (bool) {
			System.out.print("\nEnter UserName (Account Number): RB000");
			int userName = input.nextInt();

			System.out.print("Enter PassWord (Mobile Number): ");
			String passWord = input.next();

			// Validates UserName, Password 
			if (CGbankserv.checkCredentials(userName, passWord)) {
			
					account = CGbankserv.getFromAccountDatabase(userName);

					if (account.getWallet().getWalletID() == 0)
						account.getWallet().setWalletID(account.getAccountNumber());

					// Get Initial Deposit Transaction
					if (transact.getTransactList().isEmpty()
							&& account.getAccountNumber() <= CGbankserv.getAccountCount()) {
						transact.addToTransactionList(account.getAmount() + "cr -> \t" + account.getAmount());
						CGbankserv.storeIntoTransactionsDatabase(account.getAccountNumber(), transact);
					}

					mainMenu();
					bool = false;
				

				
			} else
				System.out.println("\nWrong Credentials..! Try Again.");
		}
	}

	private static boolean validateAccountNumber(int accountNumber) throws Exception {
		if (account.getAccountNumber() > 0 && accountNumber <= CGbankserv.getAccountCount()) {
			return true;
		} else {
			System.out.println("\nAccount doesn't exist!, Try again.");
			fundTransfer();
			return false;
		}
	}

	private static void creditAccount(double transferableAmount) throws Exception {
		account.setAmount(account.getAmount() + transferableAmount);

		transact.addToTransactionList(transferableAmount + "cr -> \t" + account.getAmount());
		CGbankserv.storeIntoTransactionsDatabase(account.getAccountNumber(), transact);
		CGbankserv.storeIntoAccountDatabase(account);
	}

	private static void creditAccount(double transferableAmount, Account anotherAccount) throws Exception {
		anotherAccount.setAmount(anotherAccount.getAmount() + transferableAmount);

		if (CGbankserv.getFromTransactionsDatabase(anotherAccount.getAccountNumber()) == null) {
			Transactions anotherTransact = new Transactions();

			anotherTransact.addToTransactionList(transferableAmount + "cr -> \t" + anotherAccount.getAmount());
			CGbankserv.storeIntoTransactionsDatabase(anotherAccount.getAccountNumber(), anotherTransact);
		} else {
			Transactions anotherTransact = CGbankserv
					.getFromTransactionsDatabase(anotherAccount.getAccountNumber());
			List<String> existingList = anotherTransact.getTransactList();

			existingList.add(transferableAmount + "cr -> \t" + anotherAccount.getAmount());
			anotherTransact.setTransactList(existingList);
			CGbankserv.storeIntoTransactionsDatabase(anotherAccount.getAccountNumber(), anotherTransact);
		}
		CGbankserv.storeIntoAccountDatabase(anotherAccount);
	}

	private static void debitWallet(double transferableAmount) throws Exception {
		if (account.getWallet().getWalletAmount() >= transferableAmount) {
			account.getWallet().setWalletAmount(account.getWallet().getWalletAmount() - transferableAmount);
			walletTransact
					.addToTransactionList(transferableAmount + "dr -> \t" + account.getWallet().getWalletAmount());
			CGbankserv.storeIntoWalletTransactionsDatabase(account.getWallet().getWalletID(), walletTransact);
		}

		else
			System.out.println("Insufficient Balance");
		CGbankserv.storeIntoWalletDatabase(account.getWallet());
	}

	private static void creditWallet(double transferableAmount, Wallet anotherWallet) throws Exception {
		anotherWallet.setWalletAmount(anotherWallet.getWalletAmount() + transferableAmount);

		if (CGbankserv.getFromWalletTransactionsDatabase(anotherWallet.getWalletID()) == null) {
			WalletTransactions anotherWalletTransact = new WalletTransactions();
			anotherWalletTransact
					.addToTransactionList(transferableAmount + "cr -> \t" + anotherWallet.getWalletAmount());
			CGbankserv.storeIntoWalletTransactionsDatabase(anotherWallet.getWalletID(), anotherWalletTransact);
		} else {
			WalletTransactions anotherWalletTransact = CGbankserv
					.getFromWalletTransactionsDatabase(anotherWallet.getWalletID());
			List<String> existingList = anotherWalletTransact.getTransactList();
			existingList.add(transferableAmount + "cr -> \t" + anotherWallet.getWalletAmount());
			anotherWalletTransact.setTransactList(existingList);
			CGbankserv.storeIntoWalletTransactionsDatabase(anotherWallet.getWalletID(), anotherWalletTransact);
		}
		CGbankserv.storeIntoWalletDatabase(anotherWallet);
	}

	private static void creditWallet(double transferableAmount) throws Exception {
		account.getWallet().setWalletAmount(account.getWallet().getWalletAmount() + transferableAmount);

		walletTransact.addToTransactionList(transferableAmount + "cr -> \t" + account.getWallet().getWalletAmount());
		CGbankserv.storeIntoWalletTransactionsDatabase(account.getWallet().getWalletID(), walletTransact);
		CGbankserv.storeIntoAccountDatabase(account);
		CGbankserv.storeIntoWalletDatabase(account.getWallet());
	}

	private static void debitAccount(double transferableAmount) throws Exception {
		if (account.getAmount() >= transferableAmount) {
			account.setAmount(account.getAmount() - transferableAmount);

			transact.addToTransactionList(transferableAmount + "dr -> \t" + account.getAmount());
			CGbankserv.storeIntoTransactionsDatabase(account.getAccountNumber(), transact);
		} else
			System.out.println("Insufficient Balance");
		CGbankserv.storeIntoAccountDatabase(account);
	}



}
