package com.boot.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.boot.entity.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, String> {

//	void saveByFirstname(Employee employee);

//	void saveByFirstname(Employee employee);
}
