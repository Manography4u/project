package com.boot.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.boot.entity.Employee;
import com.boot.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("employees")
	public List<Employee> getEmployees() {
		return employeeService.getAll();
	}

	@GetMapping(value = "/employees/{id}")
	public Optional<Employee> getEmployee(@PathVariable String id) {
		return employeeService.getEmployee(id);
	}

//	@RequestMapping(value = "/employees", method = RequestMethod.POST)
	@PostMapping("/employees")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee) {

		Employee e = employeeService.addEmployee(employee);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(e.getId());

		return ResponseEntity.created(location).build();

	}

	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee, @PathVariable String id) {
		Employee e = employeeService.updateEmp(employee, id);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").build(e.getId());

		return ResponseEntity.created(location).build();

		// @formatter:on

	}

	@DeleteMapping("/employees/{id}")
	public void deleteEmployee(@PathVariable String id) {
		employeeService.deleteEmp(id);
	}
}
